# app.py

from flask import Flask, request, render_template, jsonify
import requests
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
from telegram.ext import Updater, CallbackContext
import asyncio

app = Flask(__name__)

bot_token = '7687989772:AAE3FZssFptpdFRlJqchKZx43Nu48QdGmRs' 
chat_id = '-1002391577256' 

def send_to_telegram(message):
    response = requests.post(f'https://api.telegram.org/bot{bot_token}/sendMessage', data={'chat_id': chat_id, 'text': message})
    if response.status_code != 200:
        print(f"Ошибка при отправке сообщения: {response.text}")

@app.route('/')
@app.route('/main')
def index():
    return render_template('index.html') 

@app.route('/conf')
def conf():
    return render_template('conf.html')

@app.route('/connection')
def connection():
    return render_template('connection.html')

@app.route('/send', methods=['POST'])
def send():
    name = request.form['username']
    email = request.form['email']
    phone = request.form['phone']
    message = request.form['message']
    

    telegram_message = f"Получена связь от клиента.\nИмя: {name}\nEmail: {email}\nТелефон: {phone}\nСообщение: {message}"

    try:
        send_to_telegram(telegram_message)
        return jsonify({"status": "success"}), 200
    except Exception as e:
        print(f"Ошибка: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500
    

# Запуск бота
async def run_bot():
    application = ApplicationBuilder().token(bot_token).build()

    await application.run_polling()


if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    loop.create_task(run_bot())  
    app.run(host='0.0.0.0', port=5000) 