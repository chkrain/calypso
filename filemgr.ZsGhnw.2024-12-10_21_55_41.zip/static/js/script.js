document.addEventListener("DOMContentLoaded", (event) => {
    gsap.registerPlugin(Flip, ScrollTrigger, Observer, ScrollToPlugin, Draggable, MotionPathPlugin, EaselPlugin, PixiPlugin, TextPlugin);

    const sections = gsap.utils.toArray("section, footer");
    const navLinks = document.querySelectorAll('.nav a, footer a, .main-info-p-btn a');
    const nav = document.querySelector('.nav');
    let scrolling = false;
    let currentSection = 0;
    let hideTimeout;
    let touchStartY = 0;
    let mouseInTopArea = false;

    function updateCurrentSection() {
        const scrollPosition = window.scrollY + window.innerHeight / 2;
        sections.forEach((section, index) => {
            const sectionTop = section.offsetTop;
            const sectionBottom = sectionTop + section.offsetHeight;
            if (scrollPosition >= sectionTop && scrollPosition < sectionBottom) {
                currentSection = index;
            }
        });

        const footer = document.querySelector('footer');
        const footerTop = footer.offsetTop;
        const footerBottom = footerTop + footer.offsetHeight;

        if (scrollPosition >= footerTop && scrollPosition < footerBottom) {
            currentSection = sections.length - 1;
        }
    }

    navLinks.forEach(link => {
        link.addEventListener('click', (event) => {
            const targetID = link.getAttribute("href");
            const targetSection = document.querySelector(targetID);

            if (!targetSection) {
                console.warn(`Target section ${targetID} not found.`);
                return;
            }

            event.preventDefault();

            if (scrolling) return;
            scrolling = true;

            gsap.to(window, {
                duration: 1.2,
                scrollTo: { y: targetSection, autoKill: false },
                ease: "power2.inOut",
                onComplete: () => {
                    updateCurrentSection();
                    scrolling = false;
                }
            });
        });
    });

    function handleScroll(event) {
        if (scrolling) return;

        updateCurrentSection();

        if (event.deltaY > 0) {
            currentSection++;
            if (currentSection >= sections.length) {
                currentSection = sections.length - 1;
            }
            hideNav();
        } else {
            currentSection--;
            if (currentSection < 0) {
                currentSection = 0;
            }
        }

        scrolling = true;
        gsap.to(window, {
            duration: 1.2,
            scrollTo: { y: sections[currentSection], autoKill: false },
            ease: "power2.inOut",
            onComplete: () => {
                updateCurrentSection();
                scrolling = false;
            }
        });

        event.preventDefault();
    }

    window.addEventListener("touchstart", (event) => {
        if (event.touches.length > 0) {
            touchStartY = event.touches[0].clientY;
        }
    });

    window.addEventListener("touchmove", (event) => {
        if (event.touches.length > 0) {
            const touchEndY = event.touches[0].clientY;
            const deltaY = touchStartY - touchEndY;

            if (Math.abs(deltaY) > 50) {
                if (scrolling) return;

                if (deltaY > 0) {
                    currentSection++;
                    if (currentSection >= sections.length) {
                        currentSection = sections.length - 1;
                    }
                } else {
                    currentSection--;
                    if (currentSection < 0) {
                        currentSection = 0;
                    }
                }

                scrolling = true;
                gsap.to(window, {
                    duration: 0.8,
                    scrollTo: { y: sections[currentSection], autoKill: false },
                    ease: "power2.inOut",
                    onComplete: () => {
                        updateCurrentSection();
                        scrolling = false;
                    }
                });

                touchStartY = touchEndY;
            }
        }
    });

    sections.forEach((section) => {
        gsap.fromTo(section,
            { opacity: 0.6 },
            {
                opacity: 1,
                scrollTrigger: {
                    trigger: section,
                    start: "top bottom",
                    end: "bottom top",
                    scrub: true,
                }
            });
    });

    // Навигация
    function isSection1Visible() {
        const section1Rect = document.querySelector('.section-1').getBoundingClientRect();
        return (section1Rect.top >= 0 && section1Rect.bottom <= window.innerHeight);
    }

    function hideNav() {
        if (!isSection1Visible()) {
            nav.classList.add('hidden');
        }
    }

    function showNav() {
        nav.classList.remove('hidden');
    }

    document.addEventListener('mousemove', function (event) {
        if (event.clientY < window.innerHeight * 0.15) {
            showNav();
            resetHideTimeout();
        }
    });

    document.addEventListener('mousemove', function (event) {
        mouseInTopArea = event.clientY < window.innerHeight * 0.15;
    });

    setInterval(() => {
        if (nav.classList.contains('hidden') && mouseInTopArea) {
            showNav();
            resetHideTimeout();
        }
    }, 10);

    function resetHideTimeout() {
        clearTimeout(hideTimeout);
        hideTimeout = setTimeout(hideNav, 1000);
    }

    resetHideTimeout();
    showNav();

    window.addEventListener("wheel", handleScroll);
});